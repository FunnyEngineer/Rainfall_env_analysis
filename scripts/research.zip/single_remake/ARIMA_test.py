import numpy as np
import pandas as pd
from datetime import datetime
import matplotlib.pylab as plt